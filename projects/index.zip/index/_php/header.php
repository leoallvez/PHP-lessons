<header>
  <h1 class="float-l">
    <h2>CampusCalc<sup><span id="bet"> beta</span></sup></h2>
  </h1>   
  <input type="checkbox" id="control-nav" />
  <label for="control-nav" class="control-nav"><p></p></label>
  <label for="control-nav" class="control-nav-close"></label>
  <nav class="float-r">
    <ul class="list-auto">
      <li>
        <a href="#" title="Inicio">Inicio</a>
      </li>
      <li>
        <a href="#" title="Ajuda">Ajuda</a>
      </li>
      <li>
        <a href="#" title="Sobre">Sobre</a>
    </ul>
  </nav>
</header>